<?php
 /*
  * Plugin Name: Disable the Admin Bar
  * Plugin URI: https://github.com/indranilroy45
  * Description: The WordPress Admin Bar provides handy links to several key functions such as the ability to add new posts and pages, etc.
  * Version: 1.0
  * Author: Indranil Roy
  * Author URI: https://catalog.urbd.in/
  * License: GPLv2 or later
  * License URI: https://www.gnu.org/licenses/gpl-2.0.html
  */
 

  // Remove the admin bar from the front end
add_filter( 'show_admin_bar', '__return_false' );